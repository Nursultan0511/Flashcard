package org.example.flashcard;

public class Main {
    public static void main(String[] args) {
        FlashcardApp app = new FlashcardApp(args);
        app.run();
    }
}
